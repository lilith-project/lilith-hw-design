==========================================================================================

	KSZ8041TL-FTL  -  3.3V 10Base-T/100Base-TX/100Base-FX Physical Layer Transceiver


==========================================================================================

Design Package 
Revision History
----------------
	v1.0  :  Initial release
	v1.1  :	 Added KSZ8041TL/FTL Eval Board User's Guide
		 Updated AN-111 10-100 General PCB Design & Layout Guidelines
	v1.2  :	 Updated KSZ8041TL/FTL Eval Board Schematic
		 Updated KSZ8041TL/FTL Eval Board User's Guide
	v1.3  :  Added KSZ8041TL/FTL Eval Board Rev1.1 Schematic with POF option
		 Added KSZ8041TL/FTL Eval Board Rev1.1 Gerber Files with POF option
	v1.4  :  Added Errata

==========================================================================================

Please contact your local Micrel FAE or Salesperson for any question.
